
Next Higher Number with Same Number of Set Bits
----------------------------------------------

This program calculates the next higher number that has the same number of set bits (1s) in its binary representation as a given input number.

The algorithm uses bit manipulation to achieve this efficiently.

Problem Statement

Given an unsigned integer `x`, find the next greater number that has the same number of 1s in its binary representation as `x`.

For example:
- Input: `156` (binary `10011100`)
- Output: `163` (binary `10100011`) � both have 4 set bits.

How It Works

1. Identifies the rightmost set bit (1) using `x & -x`.
2. Adds it to the number to get a new base.
3. Extracts the pattern of unset bits that changed during the addition.
4. Shifts and reinserts the adjusted pattern to maintain the number of set bits.
5. Returns the final value which is the smallest number greater than `x` with the same number of 1s.

This uses advanced bit manipulation and is often used in algorithms involving combinatorics and permutations of bit masks.

How to Run
--------------------------------------------------
Make sure you have a C++ compiler installed (e.g., `g++`).

Save the code in a file, for example: `next_set_bits.cpp`

Compile and run:
-------------------------------------------
g++ next_set_bits.cpp -o next_set_bits
./next_set_bits

On Windows:
g++ next_set_bits.cpp -o next_set_bits.exe
next_set_bits.exe

