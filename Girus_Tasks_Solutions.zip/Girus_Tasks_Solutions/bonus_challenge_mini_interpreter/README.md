Mini Interpreter
-------------------
This program implements a simple interpreter in JavaScript that supports basic variable declarations and conditional statements. It can handle let statements for variable assignments and if conditions to control the flow of execution.


Features:
---------------
Variable Declaration: Supports let declarations with arithmetic expressions.

Conditionals: Executes blocks of code based on conditions using if.

Arithmetic Expressions: Evaluates basic arithmetic and comparison expressions.


How It Works:
----------------
Takes a string of code with let variable declarations and if conditions.

Evaluates arithmetic expressions and stores variables.

Executes code inside the if block if the condition is true.


Special Notes:
-----------------
Supports basic operations like +, -, *, /, ==, >, and <.

All variables are stored in an internal object called variables.

Expressions are evaluated using eval() after substituting variable names with their values.

How to Run:
----------------
Ensure you have a browser or Node.js installed.

Save the code in a file, for example: mini_interpreter.js.

Run the file in a browser's developer console or using Node.js:

Using Node.js:
node mini_interpreter.js