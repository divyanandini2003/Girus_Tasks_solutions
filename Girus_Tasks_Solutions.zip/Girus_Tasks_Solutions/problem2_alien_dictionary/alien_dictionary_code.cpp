#include <bits/stdc++.h>
using namespace std;

string deriveAlienOrder(vector<string> &dictionary, int k)
{
    vector<int> indegree(k, 0); // To track number of incoming edges
    vector<vector<int>> adjList(k); // Adjacency list to represent graph

    for (int i = 0; i < dictionary.size() - 1; i++) {
        string word1 = dictionary[i];
        string word2 = dictionary[i + 1];

        for (int j = 0; j < min(word1.size(), word2.size()); j++) {
            if (word1[j] != word2[j]) {
                indegree[word2[j] - 'a']++;
                adjList[word1[j] - 'a'].push_back(word2[j] - 'a');
                break;
            }
        }
    }

    queue<int> q;
    for (int i = 0; i < k; i++) {
        if (indegree[i] == 0) {
            q.push(i);
        }
    }

    string result = "";
    while (!q.empty()) {
        int current = q.front();
        q.pop();

        result += (current + 'a');

        for (int neighbor : adjList[current]) {
            indegree[neighbor]--;
            if (indegree[neighbor] == 0)
                q.push(neighbor);
        }
    }

    return result;
}

int main() {
    int n, k;
    cout << "Enter number of words in the dictionary: ";
    cin >> n;

    vector<string> dictionary(n);
    cout << "Enter the words:\n";
    for (int i = 0; i < n; i++) {
        cin >> dictionary[i];
    }

    cout << "Enter number of unique characters (k): ";
    cin >> k;

    string order = deriveAlienOrder(dictionary, k);
    cout << "Alien Dictionary Order: " << order << endl;

    return 0;
}

