Knights and Portals
---------------------

This program finds the shortest path from the top-left to the bottom-right cell in a grid. Each cell can be empty (0) or blocked (1). You can move in four directions (up, down, left, right) through empty cells.

You are also allowed to teleport exactly once between any two empty cells. The teleport can happen at any point in the path, and it helps in skipping over blocked areas.

The goal is to reach the destination in the minimum number of steps, using at most one teleport.

Special Notes:

If the start or end is blocked, the answer is -1.

If you teleport directly from a neighbor of start to the destination, the answer will be 2.

How It Works
Takes a grid of size n x m as input with values 0 (empty) or 1 (blocked).

Performs BFS starting from (0,0) while tracking visited states.

Allows one teleportation during traversal between two empty cells.

Calculates the minimum steps required to reach (n-1, m-1).

How to Run
----------------------------------
Make sure you have a C++ compiler (e.g., g++) installed.

Save the code in a file, for example: knights_and_portals.cpp.

Compile and run:
------------------------------------
g++ knights_and_portals.cpp -o knights_and_portals
./knights_and_portals

On Windows, run:
g++ knights_and_portals.cpp -o knights_and_portals.exe
knights_and_portals.exe
