#include <bits/stdc++.h>
using namespace std;

//  Check if all filled numbers in the group are unique (ignore -1)
bool isValidGroup(const vector<pair<int, int>>& group, vector<vector<int>>& board) {
    vector<bool> seen(10, false); // For numbers 1-9
    for (auto& cell : group) {
        int r = cell.first;
        int c = cell.second;
        int val = board[r][c];
        if (val == -1) continue; // Empty cells allowed
        if (val < 1 || val > 9 || seen[val]) return false;
        seen[val] = true;
    }
    return true;
}

bool isValidSudoku(vector<vector<int>>& board, vector<vector<pair<int, int>>>& customZones) {
    unordered_set<int> rows[9];
    unordered_set<int> cols[9];
    unordered_set<int> boxes[9];

    for (int r = 0; r < 9; ++r) {
        for (int c = 0; c < 9; ++c) {
            int value = board[r][c];
            if (value == -1) continue;

            int boxIndex = (r / 3) * 3 + (c / 3);

            if (rows[r].count(value) || cols[c].count(value) || boxes[boxIndex].count(value)) {
                return false;
            }

            rows[r].insert(value);
            cols[c].insert(value);
            boxes[boxIndex].insert(value);
        }
    }

    // ? Check custom zones
    for (auto& zone : customZones) {
        if (!isValidGroup(zone, board)) return false;
    }

    return true;
}

int main() {
    vector<vector<int>> board(9, vector<int>(9));
    for (int i = 0; i < 9; i++)
        for (int j = 0; j < 9; j++)
            cin >> board[i][j];

    int zoneCount;
    cin >> zoneCount;

    vector<vector<pair<int, int>>> customZones(zoneCount);
    for (int z = 0; z < zoneCount; z++) {
        for (int k = 0; k < 9; k++) {
            int r, c;
            cin >> r >> c;
            customZones[z].push_back({r, c});
        }
    }

    bool valid = isValidSudoku(board, customZones);
    if (valid)
        cout << "Valid Sudoku\n";
    else
        cout << "Invalid Sudoku\n";

    return 0;
}

