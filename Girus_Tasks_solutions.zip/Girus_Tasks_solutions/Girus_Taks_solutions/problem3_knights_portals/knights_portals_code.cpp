#include <iostream>
#include <queue>
#include <vector>
#include <climits>

using namespace std;

struct Cell {
    int x, y, dist;  // (x, y) coordinates and distance from the start
};

bool isValid(int x, int y, int n, int m, vector<vector<int>>& grid) {
    return (x >= 0 && x < n && y >= 0 && y < m && grid[x][y] == 0);
}

int shortestPathWithTeleportation(vector<vector<int>>& grid, int n, int m) {
    // Base case: Check if start and end are the same cell
    if (n == 1 && m == 1 && grid[0][0] == 0) {
        return 0;
    }

    // If start or end is blocked
    if (grid[0][0] == 1 || grid[n-1][m-1] == 1) return -1;

    vector<vector<int>> dist(n, vector<int>(m, INT_MAX));
    dist[0][0] = 0;

    queue<Cell> q;
    
    // Start BFS from the neighbors of the starting point (0, 0)
    if (isValid(0, 1, n, m, grid)) {  // Right neighbor
        dist[0][1] = 1;
        q.push({0, 1, 1});
    }
    if (isValid(1, 0, n, m, grid)) {  // Down neighbor
        dist[1][0] = 1;
        q.push({1, 0, 1});
    }

    vector<int> directions = {-1, 0, 1, 0, 0, -1, 0, 1};

    while (!q.empty()) {
        Cell curr = q.front();
        q.pop();

        // Explore all four adjacent cells
        for (int i = 0; i < 4; i++) {
            int newX = curr.x + directions[i*2];
            int newY = curr.y + directions[i*2+1];

            if (isValid(newX, newY, n, m, grid) && dist[newX][newY] == INT_MAX) {
                dist[newX][newY] = curr.dist + 1;
                q.push({newX, newY, curr.dist + 1});
            }
        }

        // Handle teleportation to all other empty cells (only once BFS reaches a point)
        // This is the step that allows jumps between empty cells
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (grid[i][j] == 0 && dist[i][j] == INT_MAX) {  // Empty cell
                    dist[i][j] = curr.dist + 1;
                    q.push({i, j, curr.dist + 1});
                }
            }
        }
    }

    return dist[n-1][m-1] == INT_MAX ? -1 : dist[n-1][m-1];
}

int main() {
    // Take user input for grid size
    int n, m;
//    cout << "Enter the number of rows (n): ";
    cin >> n;
//    cout << "Enter the number of columns (m): ";
    cin >> m;

    // Take user input for the grid itself
    vector<vector<int>> grid(n, vector<int>(m));
//    cout << "Enter the grid (0 for empty, 1 for blocked):\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> grid[i][j];
        }
    }

    // Call the function and display the result
    int result = shortestPathWithTeleportation(grid, n, m);
    cout << "The shortest path with teleportation is: " << result << endl;

    return 0;
}

