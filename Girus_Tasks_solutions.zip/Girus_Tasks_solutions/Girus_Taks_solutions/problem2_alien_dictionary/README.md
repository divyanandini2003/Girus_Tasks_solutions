Alien Dictionary Order
--------------------------

This program determines a valid order of characters in an alien language, given a sorted dictionary of words. It uses topological sorting to establish the relative character order based on pairwise word comparisons.

The solution assumes the characters are lowercase English letters and that the dictionary is sorted according to the alien language's unknown alphabetical order.

How It Works
-------------

A list of n words in sorted order (according to alien dictionary).

An integer k representing the number of unique characters (from 'a' to the (k-1)th letter).

Builds a directed graph of character dependencies.

Performs a BFS-based topological sort (Kahn�s Algorithm).

Outputs one possible valid character order if it exists.

How to Run
------------
Make sure you have a C++ compiler (e.g., g++) installed.

Save the code in a file, for example: alien_dictionary.cpp.

Compile and run:
----------------

g++ alien_dictionary.cpp -o alien_dictionary
./alien_dictionary

On Windows, run:

g++ alien_dictionary.cpp -o alien_dictionary.exe
alien_dictionary.exe
