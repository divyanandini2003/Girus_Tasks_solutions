#include <iostream>
using namespace std;
using uint = unsigned int;

// Function to find the next greater number with the same number of 1 bits
uint getNextWithSameSetBits(uint num) {
    if (num == 0) return 0;

    // Step 1: Get the rightmost set bit
    uint lowestSetBit = num & -static_cast<int>(num);

    // Step 2: Add it to the number to get the next higher one bit
    uint incremented = num + lowestSetBit;

    // Step 3: Identify bits that changed
    uint changedBits = num ^ incremented;

    // Step 4: Adjust the right side of the bits
    changedBits = (changedBits / lowestSetBit) >> 2;

    // Step 5: Combine to get the final result
    return incremented | changedBits;
}

int main() {
	
    uint inputNumber;
    cin>>inputNumber;
    
    uint result = getNextWithSameSetBits(inputNumber);

    cout << "Next number with same number of set bits as " 
         << inputNumber << " is: " << result << endl;

    return 0;
    
}

