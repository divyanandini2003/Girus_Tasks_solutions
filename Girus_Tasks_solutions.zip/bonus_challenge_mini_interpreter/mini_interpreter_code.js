// Store variables
let variables = {};

// Function to evaluate arithmetic expressions
function evaluateExpression(expr) {
    try {
        // Replace variable names with their values from the variables object
        for (let varName in variables) {
            let regex = new RegExp(`\\b${varName}\\b`, 'g');
            expr = expr.replace(regex, variables[varName]);
        }
        
        // Remove any spaces and evaluate the expression safely
        expr = expr.replace(/\s+/g, '');
        
        // Evaluate the expression using eval
        return eval(expr);
    } catch (e) {
        console.error("Error evaluating expression:", expr);
        return undefined;
    }
}

// Function to process 'let' statements (variable declarations)
function processLetStatement(statement) {
    let match = statement.match(/let (\w+) = (.+);/);
    if (match) {
        let varName = match[1];
        let expr = match[2];
        let value = evaluateExpression(expr);
        if (value !== undefined) {
            variables[varName] = value;
            console.log(`Variable '${varName}' set to ${value}`);
        }
    } else {
        console.log("Invalid 'let' statement:", statement);
    }
}

// Function to process 'if' statements (conditional execution)
function processIfStatement(statement) {
    let match = statement.match(/if \((.*?)\) \{(.*?)\}/);
    if (match) {
        let condition = match[1].trim();
        let block = match[2].trim();

        // Evaluate the condition
        let conditionMet = evaluateExpression(condition);
        if (conditionMet) {
            console.log(`Condition met. Executing block: ${block}`);
            // Execute the block inside the if (this assumes it contains a 'let' statement)
            processLetStatement(block);
        } else {
            console.log("Condition not met.");
        }
    } else {
        console.log("Invalid 'if' statement:", statement);
    }
}

// Function to process the input code line by line
function processCode(input) {
    let lines = input.split("\n");
    lines.forEach(line => {
        line = line.trim();
        if (line.startsWith("let")) {
            processLetStatement(line);
        } else if (line.startsWith("if")) {
            processIfStatement(line);
        }
    });
}

// Example usage
let inputCode = `
let x = 10;
let y = x + 5;
if (x == 10) { let z = y + 3; }
if (x > 5) { let w = z * 2; }
if (x < 5) { let z = 0; }
`;

processCode(inputCode);
