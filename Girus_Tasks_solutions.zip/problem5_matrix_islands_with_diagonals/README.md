Matrix Islands with Diagonals
------------------------------

This program counts the number of islands in a given matrix of 0s and 1s. Islands are formed by connected 1s. The connection can be horizontal, vertical, or diagonal.

You will be given a matrix of size n x m, and the program will determine how many distinct islands are present, considering diagonal connections as well.

How It Works
-------------
1. Takes a matrix of 0s and 1s as input.
2. Each 1 represents land, and each 0 represents water.
3. The program identifies islands formed by adjacent 1s (including diagonals).
4. It returns the total count of islands in the matrix.

How to Run
-----------
1. Make sure you have a C++ compiler installed (e.g., g++).
2. Save the code in a file, for example: matrix_islands.cpp.
3. Compile and run the program:

   g++ matrix_islands.cpp -o matrix_islands
   ./matrix_islands

On Windows:
   g++ matrix_islands.cpp -o matrix_islands.exe
   matrix_islands.exe

Input Format:
-------------
1. The first line of input specifies the number of rows and columns (n m).
2. The next n lines contain m space-separated integers (0 or 1), representing the matrix.

Output Format:
--------------
The program will output the number of islands formed in the matrix, considering diagonal connections.


