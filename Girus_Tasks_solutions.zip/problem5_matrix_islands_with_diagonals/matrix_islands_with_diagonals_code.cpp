#include <iostream>
#include <vector>
using namespace std;

// Direction vectors for 8 possible movements (including diagonals)
int rowShift[] = {-1, -1, -1, 0, 0, 1, 1, 1};
int colShift[] = {-1, 0, 1, -1, 1, -1, 0, 1};

// Perform DFS from the current land cell
void exploreIsland(int row, int col, vector<vector<int>>& map, vector<vector<bool>>& seen, int totalRows, int totalCols) {
    seen[row][col] = true;

    for (int dir = 0; dir < 8; dir++) {
        int newRow = row + rowShift[dir];
        int newCol = col + colShift[dir];

        if (newRow >= 0 && newRow < totalRows &&
            newCol >= 0 && newCol < totalCols &&
            map[newRow][newCol] == 1 &&
            !seen[newRow][newCol]) {
            exploreIsland(newRow, newCol, map, seen, totalRows, totalCols);
        }
    }
}

// Count number of islands (connected groups of 1s)
int countConnectedIslands(vector<vector<int>>& map) {
    int totalRows = map.size();
    if (totalRows == 0) return 0;
    int totalCols = map[0].size();

    vector<vector<bool>> seen(totalRows, vector<bool>(totalCols, false));
    int islandTotal = 0;

    for (int row = 0; row < totalRows; row++) {
        for (int col = 0; col < totalCols; col++) {
            if (map[row][col] == 1 && !seen[row][col]) {
                exploreIsland(row, col, map, seen, totalRows, totalCols);
                islandTotal++;
            }
        }
    }

    return islandTotal;
}

int main() {
    int rows, cols;
    cout << "Enter number of rows and columns: ";
    cin >> rows >> cols;

    vector<vector<int>> map(rows, vector<int>(cols));
    cout << "Enter the matrix values (0s and 1s only):" << endl;
    for (int i = 0; i < rows; i++)
        for (int j = 0; j < cols; j++)
            cin >> map[i][j];

    int totalIslands = countConnectedIslands(map);
    cout << "Number of islands (considering diagonal connections): " << totalIslands << endl;

    return 0;
}

