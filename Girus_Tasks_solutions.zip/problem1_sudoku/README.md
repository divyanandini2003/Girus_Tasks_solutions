Sudoku Validator with Custom Zones
-------------------------------------

This program validates a standard 9X9 Sudoku board with additional support for custom zones, ensuring that each row, column, 3X3 subgrid, and each custom zone contains digits 1 - 9 without repetition.


## How It Works

- Accepts a 9X9 grid of integers from user input.
- Empty cells are represented by -1.
- Supports validation of additional user-defined custom zones (each containing 9 unique cells).
- Validates:
  - Each row contains unique digits 1- 9
  - Each column contains unique digits 1 - 9
  - Each 3X3 box contains unique digits 1 - 9
  - Each custom zone contains unique digits 1 - 9


## How to Run

1. Make sure you have a C++ compiler (e.g., `g++`) installed.
2. Compile and run:

g++ sudoku_validator.cpp -o sudoku_validator
./sudoku_validator

